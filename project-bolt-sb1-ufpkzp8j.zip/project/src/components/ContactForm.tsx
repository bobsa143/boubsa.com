import React, { useState } from 'react';

const ContactForm: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission
    console.log(formData);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label htmlFor="name" className="block text-sm font-medium mb-2">
            Nom complet
          </label>
          <input
            type="text"
            id="name"
            name="name"
            value={formData.name}
            onChange={handleChange}
            className="w-full px-4 py-2 rounded-md bg-[#1A1A1A] border border-gray-600 focus:border-[#FFD700] focus:outline-none"
            required
          />
        </div>
        <div>
          <label htmlFor="email" className="block text-sm font-medium mb-2">
            Email
          </label>
          <input
            type="email"
            id="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            className="w-full px-4 py-2 rounded-md bg-[#1A1A1A] border border-gray-600 focus:border-[#FFD700] focus:outline-none"
            required
          />
        </div>
      </div>
      <div>
        <label htmlFor="phone" className="block text-sm font-medium mb-2">
          Téléphone
        </label>
        <input
          type="tel"
          id="phone"
          name="phone"
          value={formData.phone}
          onChange={handleChange}
          className="w-full px-4 py-2 rounded-md bg-[#1A1A1A] border border-gray-600 focus:border-[#FFD700] focus:outline-none"
          required
        />
      </div>
      <div>
        <label htmlFor="subject" className="block text-sm font-medium mb-2">
          Sujet
        </label>
        <select
          id="subject"
          name="subject"
          value={formData.subject}
          onChange={handleChange}
          className="w-full px-4 py-2 rounded-md bg-[#1A1A1A] border border-gray-600 focus:border-[#FFD700] focus:outline-none"
          required
        >
          <option value="">Sélectionnez un sujet</option>
          <option value="devis">Demande de devis</option>
          <option value="urgence">Intervention d'urgence</option>
          <option value="information">Demande d'information</option>
          <option value="autre">Autre</option>
        </select>
      </div>
      <div>
        <label htmlFor="message" className="block text-sm font-medium mb-2">
          Message
        </label>
        <textarea
          id="message"
          name="message"
          value={formData.message}
          onChange={handleChange}
          rows={4}
          className="w-full px-4 py-2 rounded-md bg-[#1A1A1A] border border-gray-600 focus:border-[#FFD700] focus:outline-none"
          required
        ></textarea>
      </div>
      <button
        type="submit"
        className="w-full bg-[#FFD700] text-[#2C2C2C] px-6 py-3 rounded-md font-semibold hover:bg-[#E5C400] transition-colors"
      >
        Envoyer le message
      </button>
    </form>
  );
};

export default ContactForm;