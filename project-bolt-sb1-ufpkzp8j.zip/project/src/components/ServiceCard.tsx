import React from 'react';
import { Wrench, AlertTriangle, PenTool as Tool, RefreshCw } from 'lucide-react';

interface ServiceCardProps {
  title: string;
  description: string;
}

const iconMap = {
  'Inspection & Diagnostic': AlertTriangle,
  'Réparation & Remplacement': Wrench,
  'Entretien Préventif': Tool,
  'Modernisation': RefreshCw,
};

const ServiceCard: React.FC<ServiceCardProps> = ({ title, description }) => {
  const Icon = iconMap[title as keyof typeof iconMap] || AlertTriangle;

  return (
    <div className="bg-white p-6 rounded-lg shadow-lg hover:shadow-xl transition-shadow">
      <div className="w-12 h-12 bg-[#FFD700] rounded-full flex items-center justify-center mb-4">
        <Icon className="w-6 h-6 text-[#2C2C2C]" />
      </div>
      <h3 className="text-xl font-bold mb-3 text-[#2C2C2C]">{title}</h3>
      <p className="text-gray-600 mb-4">{description}</p>
      <button className="text-[#2C2C2C] font-semibold hover:text-[#FFD700] transition-colors">
        En savoir plus →
      </button>
    </div>
  );
};

export default ServiceCard;