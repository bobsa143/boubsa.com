import React from 'react';

interface BlogPostProps {
  title: string;
  category: string;
  date: string;
}

const BlogPost: React.FC<BlogPostProps> = ({ title, category, date }) => {
  return (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden">
      <div className="h-48 bg-gray-200">
        <img
          src={`https://images.unsplash.com/photo-1504307651254-35680f356dfd?auto=format&fit=crop&w=600&q=60`}
          alt={title}
          className="w-full h-full object-cover"
        />
      </div>
      <div className="p-6">
        <div className="flex items-center mb-2">
          <span className="text-sm text-[#FFD700] font-semibold">{category}</span>
          <span className="mx-2">•</span>
          <span className="text-sm text-gray-500">{date}</span>
        </div>
        <h3 className="text-xl font-bold mb-2 text-[#2C2C2C]">{title}</h3>
        <button className="text-[#2C2C2C] font-semibold hover:text-[#FFD700] transition-colors">
          Lire la suite →
        </button>
      </div>
    </div>
  );
};

export default BlogPost;