import React from 'react';
import { Award, Clock, Shield, TrendingUp } from 'lucide-react';

interface AdvantageCardProps {
  title: string;
  description: string;
}

const iconMap = {
  'Certification et expertise': Award,
  'Disponibilité 24/7': Clock,
  'Conformité normes ISO/EN': Shield,
  'ROI client démontré': TrendingUp,
};

const AdvantageCard: React.FC<AdvantageCardProps> = ({ title, description }) => {
  const Icon = iconMap[title as keyof typeof iconMap] || Award;

  return (
    <div className="bg-white p-8 rounded-lg shadow-lg hover:shadow-xl transition-shadow">
      <div className="w-12 h-12 bg-[#FFD700] rounded-full flex items-center justify-center mb-4">
        <Icon className="w-6 h-6 text-[#2C2C2C]" />
      </div>
      <h3 className="text-xl font-bold mb-3 text-[#2C2C2C]">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </div>
  );
};

export default AdvantageCard;