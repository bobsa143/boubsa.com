import React from 'react';
import { Phone, ChevronDown, Mail, Menu } from 'lucide-react';
import ServiceCard from './components/ServiceCard';
import AdvantageCard from './components/AdvantageCard';
import BlogPost from './components/BlogPost';
import ContactForm from './components/ContactForm';

function App() {
  return (
    <div className="min-h-screen bg-white">
      {/* Emergency Banner */}
      <div className="bg-[#2C2C2C] text-white py-2 px-4 fixed w-full top-0 z-50 flex justify-center items-center">
        <Phone className="w-4 h-4 mr-2" />
        <span>Intervention 24/7 :  +212 675 15 48 48 /
                    +221 78 482 72 29 </span>
      </div>

      {/* Navigation */}
      <nav className="bg-white shadow-lg mt-10 sticky top-10 z-40">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <span className="text-2xl font-bold text-[#2C2C2C]">ElecBob</span>
            </div>
            <div className="hidden md:flex items-center space-x-8">
              <a href="#services" className="text-[#2C2C2C] hover:text-[#FFD700]">Services</a>
              <a href="#advantages" className="text-[#2C2C2C] hover:text-[#FFD700]">Avantages</a>
              <a href="#blog" className="text-[#2C2C2C] hover:text-[#FFD700]">Blog</a>
              <a href="#contact" className="text-[#2C2C2C] hover:text-[#FFD700]">Contact</a>
              <button className="bg-[#FFD700] text-[#2C2C2C] px-6 py-2 rounded-md font-semibold hover:bg-[#E5C400] transition-colors">
                Demandez un devis
              </button>
            </div>
            <div className="md:hidden">
              <Menu className="w-6 h-6" />
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <div className="relative h-[80vh] bg-cover bg-center" style={{
        backgroundImage: 'url("https://images.unsplash.com/photo-1504307651254-35680f356dfd?auto=format&fit=crop&w=1920&q=80")'
      }}>
        <div className="absolute inset-0 bg-black bg-opacity-50" />
        <div className="relative max-w-7xl mx-auto px-4 h-full flex items-center">
          <div className="text-white">
            <h1 className="text-5xl md:text-6xl font-bold mb-6">
              Maintenance des Grues à Tour<br />
              <span className="text-[#FFD700]">Sécurité & Performance</span>
            </h1>
            <p className="text-xl mb-8 max-w-2xl">
              Leader dans la maintenance et l'entretien des grues à tour. 
              Notre expertise garantit la sécurité et la performance de vos équipements.
            </p>
            <button className="bg-[#FFD700] text-[#2C2C2C] px-8 py-4 rounded-md text-lg font-semibold hover:bg-[#E5C400] transition-colors">
              Demandez un devis
            </button>
          </div>
        </div>
        <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 mb-8">
          <ChevronDown className="w-8 h-8 text-white animate-bounce" />
        </div>
      </div>

      {/* Services Section */}
      <section id="services" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-4xl font-bold text-center mb-16 text-[#2C2C2C]">Nos Services</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
             <ServiceCard 
              title="Montage & Demontage"
              description="Des services spécialisés dans l'installation et le démontage des grues sur chantier,Étude et préparation du site.
Assemblage des éléments (mât, flèche, contrepoids, mécanismes).
Installation et mise en service."
            />
            <ServiceCard 
              title="Inspection & Diagnostic"
              description="Évaluation complète de vos grues avec des outils de pointe pour garantir leur conformité et leur sécurité."
            />
            <ServiceCard 
              title="Réparation & Remplacement"
              description="Intervention rapide et efficace pour maintenir vos équipements en parfait état de fonctionnement."
            />
            <ServiceCard 
              title="Entretien Préventif"
              description="Programme personnalisé de maintenance pour prévenir les pannes et optimiser la durée de vie de vos grues."
            />
            <ServiceCard 
              title="Modernisation"
              description="Mise à niveau de vos équipements selon les dernières normes de sécurité et innovations technologiques."
            />
          </div>
        </div>
      </section>

      {/* Advantages Section */}
      <section id="advantages" className="py-20 bg-[#F5F5F5]">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-4xl font-bold text-center mb-16 text-[#2C2C2C]">Nos Avantages</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <AdvantageCard 
              title="Certification et expertise"
              description="Équipe certifiée aux normes internationales"
            />
            <AdvantageCard 
              title="Disponibilité 24/7"
              description="Service d'urgence disponible jour et nuit"
            />
            <AdvantageCard 
              title="Conformité normes ISO/EN"
              description="Respect strict des standards européens"
            />
            <AdvantageCard 
              title="ROI client démontré"
              description="Optimisation des coûts de maintenance"
            />
          </div>
        </div>
      </section>

      {/* Blog Section */}
      <section id="blog" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-4xl font-bold text-center mb-16 text-[#2C2C2C]">Blog & Actualités</h2>
          <div className="flex justify-center mb-8 space-x-4">
            <button className="px-6 py-2 rounded-md bg-[#FFD700] text-[#2C2C2C] font-semibold">Maintenance</button>
            <button className="px-6 py-2 rounded-md bg-[#E5E5E5] text-[#2C2C2C] font-semibold">Innovation</button>
            <button className="px-6 py-2 rounded-md bg-[#E5E5E5] text-[#2C2C2C] font-semibold">Études de cas</button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <BlogPost 
              title="Les nouvelles normes de sécurité 2024"
              category="Maintenance"
              date="15 Mars 2024"
            />
            <BlogPost 
              title="Innovation dans l'inspection des grues"
              category="Innovation"
              date="10 Mars 2024"
            />
            <BlogPost 
              title="Optimisation des coûts de maintenance"
              category="Études de cas"
              date="5 Mars 2024"
            />
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 bg-[#2C2C2C] text-white">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-4xl font-bold text-center mb-16">Contactez-nous</h2>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <ContactForm />
            <div className="space-y-8">
              <div>
                <h3 className="text-2xl font-semibold mb-4">Coordonnées</h3>
                <div className="space-y-4">
                  <p className="flex items-center">
                    <Phone className="w-5 h-5 mr-2" />
                    +212 675 15 48 48 /
                    +221 78 482 72 29
                  </p>
                  <p className="flex items-center">
                    <Mail className="w-5 h-5 mr-2" />
                   elecbob8@gmail.com
                  </p>
                </div>
              </div>
              <div className="h-64 bg-[#E5E5E5] rounded-lg">
                {/* Google Maps will be integrated here */}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#1A1A1A] text-white py-12">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-xl font-bold mb-4">ElecBob</h3>
              <p className="text-sm text-gray-400">
                Leader dans la maintenance et l'entretien des grues à tour depuis 1995.
              </p>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">Services</h4>
              <ul className="space-y-2 text-gray-400">
                <li>Inspection & Diagnostic</li>
                <li>Réparation & Remplacement</li>
                <li>Entretien Préventif</li>
                <li>Modernisation</li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">Légal</h4>
              <ul className="space-y-2 text-gray-400">
                <li>Mentions légales</li>
                <li>Politique de confidentialité</li>
                <li>CGV</li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">Newsletter</h4>
              <form className="space-y-4">
                <input
                  type="email"
                  placeholder="Votre email"
                  className="w-full px-4 py-2 rounded-md bg-[#2C2C2C] text-white"
                />
                <button className="w-full bg-[#FFD700] text-[#2C2C2C] px-4 py-2 rounded-md font-semibold">
                  S'abonner
                </button>
              </form>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;